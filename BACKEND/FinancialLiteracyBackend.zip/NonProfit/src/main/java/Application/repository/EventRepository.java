package Application.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Application.entity.EventRecord;

public interface EventRepository extends JpaRepository<EventRecord, Integer> {

}
