package Application.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import Application.entity.Ticket;
import Application.repository.TicketRepository;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class TicketController {

  @Autowired
  private TicketRepository ticketRepository;

  @RequestMapping(value = "viewTicket", method = RequestMethod.GET)
  public ResponseEntity<?> viewTicket(@RequestParam int id) {

    return new ResponseEntity<>(ticketRepository.findById(id), HttpStatus.OK);
  }

  @RequestMapping(value = "modifyTicket", method = RequestMethod.PUT)
  public ResponseEntity<?> modifyTicket(@RequestParam int ticketId, @RequestParam int ticketType,
                                        @RequestParam int eventId, @RequestParam int userId) {

    return new ResponseEntity<>(ticketRepository.save(Ticket.builder().id(ticketId).ticketType(ticketType).userId(userId).eventRecord(eventId).build()), HttpStatus.OK);
  }

  @RequestMapping(value = "createTicket", method = RequestMethod.POST)
  public ResponseEntity<?> createTicket(
                                        @RequestParam int ticketType, @RequestParam int eventId, @RequestParam int userId) {

    return new ResponseEntity<>(ticketRepository.save(Ticket.builder().ticketType(ticketType).userId(userId).eventRecord(eventId).build()), HttpStatus.CREATED);
  }
}
