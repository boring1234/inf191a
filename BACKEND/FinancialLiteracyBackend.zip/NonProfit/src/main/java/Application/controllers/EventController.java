package Application.controllers;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import Application.entity.EventRecord;
import Application.repository.EventRepository;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/")
@RestController
public class EventController {
  @Autowired
  private EventRepository eventRepository;

  @RequestMapping(value = "viewEvent", method = RequestMethod.GET)
  public ResponseEntity<?> viewEvent(@RequestParam int eventId) {


    return new ResponseEntity<>(eventRepository.findById(eventId), HttpStatus.OK);
  }

  @RequestMapping(value = "modifyEvent", method = RequestMethod.PUT)
  public ResponseEntity<?> modifyEvent(@RequestParam int eventId, @RequestParam String eventName, @RequestParam String subHeader,
                                       @RequestParam String description, @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
                                       @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate, @RequestParam boolean published) {

    return new ResponseEntity<>( eventRepository.save(eventRepository.save(EventRecord.builder().id(eventId).eventName(eventName).subHeader(subHeader)
            .description(description).startDate(startDate).endDate(endDate).published(published).build())), HttpStatus.OK);
  }

  @RequestMapping(value = "createEvent", method = RequestMethod.POST)
  public ResponseEntity<?> createEvent(@RequestParam String eventName, @RequestParam String subHeader,
                                       @RequestParam String description, @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
                                       @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate, @RequestParam boolean published) {


    return new ResponseEntity<>(eventRepository.save(eventRepository.save(EventRecord.builder().eventName(eventName).subHeader(subHeader)
            .description(description).startDate(null).endDate(null).published(published).build())), HttpStatus.CREATED);
  }
}
