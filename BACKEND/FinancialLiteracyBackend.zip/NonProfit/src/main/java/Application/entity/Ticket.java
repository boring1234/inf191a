package Application.entity;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Ticket")
public class Ticket {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id;
  private int ticketType;
  private int eventRecord;
  private int userId;

}
enum TicketType {
  FREE_TICKET,
  PAID_TICKET,
  MERCHANDISE_ADD_ON,
  DONATION_TICKET
};