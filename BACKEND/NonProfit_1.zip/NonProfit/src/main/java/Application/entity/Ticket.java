package Application.entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Ticket {
  public final int FREE_TICKET = 1;
  public final int PAID_TICKET = 2;
  public final int MERCHANDISE_ADD_ON = 3;
  public final int DONATION_TICKET = 4;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id;
  private int ticketType;
  private int eventRecord;
}
