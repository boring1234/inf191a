package Application.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import Application.entity.Ticket;
import Application.repository.TicketRepository;

public class TicketController {

  @Autowired
  private TicketRepository ticketRepository;

  @RequestMapping(value = "viewTicket", method = RequestMethod.GET)
  public ResponseEntity<?> viewTicket(@RequestParam int id) {

    return new ResponseEntity<>(ticketRepository.findById(id), HttpStatus.OK);
  }

  @RequestMapping(value = "modifyTicket", method = RequestMethod.PUT)
  public ResponseEntity<?> modifyTicket(@RequestParam int accessLevel, @RequestParam int ticketType,
                                        @RequestParam int eventRecord) {

    ticketRepository.save(Ticket.builder().ticketType(ticketType).eventRecord(eventRecord).build());
    return new ResponseEntity<String>(HttpStatus.OK);
  }

  @RequestMapping(value = "createTicket", method = RequestMethod.POST)
  public ResponseEntity<?> createTicket(@RequestParam int accessLevel,
                                        @RequestParam int ticketType, @RequestParam int eventRecord) {
    ticketRepository.save(Ticket.builder().ticketType(ticketType).eventRecord(eventRecord).build());
    return new ResponseEntity<String>(HttpStatus.CREATED);
  }
}
