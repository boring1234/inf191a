package Application.controllers;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import Application.entity.EventRecord;
import Application.repository.EventRepository;

public class EventController {
  @Autowired
  private EventRepository eventRepository;

  @RequestMapping(value = "viewEvent", method = RequestMethod.GET)
  public ResponseEntity<?> viewEvent(int eventId) {


    return new ResponseEntity<>(eventRepository.findById(eventId), HttpStatus.OK);
  }

  @RequestMapping(value = "modifyEvent", method = RequestMethod.PUT)
  public ResponseEntity<?> modifyEvent(@RequestParam String name, @RequestParam String subHeader,
                                       @RequestParam String description, @RequestParam Date startDate,
                                       @RequestParam Date endDate, @RequestParam boolean published) {
    eventRepository.save(eventRepository.save(EventRecord.builder().name(name).subHeader(subHeader)
      .description(description).startDate(startDate).endDate(endDate).published(published).build()));
    return new ResponseEntity<String>(HttpStatus.OK);
  }

  @RequestMapping(value = "createEvent", method = RequestMethod.POST)
  public ResponseEntity<?> createEvent(@RequestParam String name, @RequestParam String subHeader,
                                       @RequestParam String description, @RequestParam Date startDate,
                                       @RequestParam Date endDate, @RequestParam boolean published) {

    eventRepository.save(eventRepository.save(EventRecord.builder().name(name).subHeader(subHeader)
      .description(description).startDate(startDate).endDate(endDate).published(published).build()));
    return new ResponseEntity<String>(HttpStatus.CREATED);
  }
}
